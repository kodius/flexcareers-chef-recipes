# deploy_resoruce Cookbook CHANGELOG

This file is used to list changes made in each version of the deploy_resoruce cookbook.

## 1.0.2 (2018-05-10)

- Stop showing deprecation warning when using the cookbook
- Allow setting timeouts to various deploy steps

## 1.0.1 (2018-04-06)

- remove broken require statement
