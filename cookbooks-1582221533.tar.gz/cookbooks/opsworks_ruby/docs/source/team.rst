Author and Contributors
=======================

Author
------

`Igor Rzegocki`_ (`@ajgon`_)

Contributors
------------

* Nick Marden (`@nickmarden`_)
* Phong Si (`@phongsi`_)
* Kevin Olbrich (`@olbrich`_)
* Kevin Pheasey (`@kpheasey`_)
* Nathan Flood (`@npflood`_)
* Teruo Adachi (`@interu`_)
* Marcos Beirigo (`@marcosbeirigo`_)
* John Calvin Young (`@johncalvinyoung`_)
* Rich Seviora (`@richseviora`_)

.. _Igor Rzegocki: https://www.rzegocki.pl/
.. _@ajgon: https://github.com/ajgon
.. _@nickmarden: https://github.com/nickmarden
.. _@phongsi: https://github.com/phongsi
.. _@olbrich: https://github.com/olbrich
.. _@kpheasey: https://github.com/kpheasey
.. _@npflood: https://github.com/npflood
.. _@interu: https://github.com/interu
.. _@marcosbeirigo: https://github.com/marcosbeirigo
.. _@johncalvinyoung: https://github.com/johncalvinyoung
.. _@richseviora: https://github.com/richseviora
